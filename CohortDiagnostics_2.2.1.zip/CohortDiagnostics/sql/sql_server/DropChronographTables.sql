{DEFAULT @cohort_database_schema = ''}

TRUNCATE TABLE @cohort_database_schema.exp_ICTPD;

DROP TABLE @cohort_database_schema.exp_ICTPD;

TRUNCATE TABLE @cohort_database_schema.comp_ICTPD;

DROP TABLE @cohort_database_schema.comp_ICTPD;

TRUNCATE TABLE @cohort_database_schema.exp_out_ICTPD;

DROP TABLE @cohort_database_schema.exp_out_ICTPD;

TRUNCATE TABLE  @cohort_database_schema.comp_out_ICTPD;

DROP TABLE  @cohort_database_schema.comp_out_ICTPD;

TRUNCATE TABLE @cohort_database_schema.period_ICTPD;

DROP TABLE @cohort_database_schema.period_ICTPD;

